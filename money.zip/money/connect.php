<?php 

$conn = new mysqli("localhost","root","", "money1");
?>